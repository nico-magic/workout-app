package com.example.workoutapprebornkotlin.data

import androidx.lifecycle.LiveData

class WorkoutAppRepository(private val exerciseDao: ExerciseDao) {

    val readAllDAta: LiveData<List<Exercise>> = exerciseDao.readAllData()

    suspend fun addExercise(exercise: Exercise){
        exerciseDao.addExercise(exercise)
    }
}