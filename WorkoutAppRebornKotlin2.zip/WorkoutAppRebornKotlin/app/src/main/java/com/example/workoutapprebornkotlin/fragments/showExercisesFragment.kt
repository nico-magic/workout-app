package com.example.workoutapprebornkotlin.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.workoutapprebornkotlin.R

class showExercisesFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_show_exercises, container, false)

        view.floatingActionButton.setOnClickListener{
            findNavController().navigate(R.id.action_showExercisesFragment_to_addExerciseFragment)
        }


        return view
    }

}