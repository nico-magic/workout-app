package com.example.workoutapprebornkotlin.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class WorkoutAppViewModel(application: Application): AndroidViewModel(application) {

    private val readAllData: LiveData<List<Exercise>>
    private val repository: WorkoutAppRepository

    init{
        val exerciseDao = ExerciseAppDatabase.getDatabase(application).exerciseDao()
        repository = WorkoutAppRepository(exerciseDao)
        readAllData = repository.readAllDAta
    }

    fun addExercise(exercise: Exercise){
        viewModelScope.launch(Dispatchers.IO){
            repository.addExercise(exercise)
        }
    }
}