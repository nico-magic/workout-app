package com.example.workoutapprebornkotlin.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ExerciseDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addExercise(exercise: Exercise)

    @Query("SELECT * FROM exercises ORDER BY id ASC")
    fun readAllData(): LiveData<List<Exercise>>
}