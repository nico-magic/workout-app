package com.example.workoutapprebornkotlin.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "exercises")
data class Exercise (
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    val exercise_name: String,
    val exercise_image: ByteArray
)